// import React, { useEffect, useState, useCallback } from 'react';
// import axios from 'axios';
import React from 'react';

const CommentList = ({ comments }) => {
  //   const [comments, setComments] = useState([]);

  //   const fetchComments = useCallback(async () => {
  //     const res = await axios.get(
  //       `http://localhost:4001/posts/${postId}/comments`
  //     );
  //     setComments(res.data);
  //   }, [postId]);

  //   useEffect(() => {
  //     fetchComments();
  //   }, [fetchComments]);

  const renderedComments = comments.map((comment) => {
    let content;
    switch (comment.status) {
      case 'pending':
        content = 'This comment is awaiting moderation';
        break;
      case 'approved':
        content = comment.content;
        break;
      case 'rejected':
        content = 'The comment has been rejected';
        break;
      default:
        content = comment.content;
    }
    return <li key={comment.id}>{content}</li>;
  });

  return <ul>{renderedComments}</ul>;
};

export default CommentList;
