const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const axios = require('axios');

const app = express();
app.use(bodyParser.json());
app.use(cors());

const handleEvent = (type, data) => {
  if (type === 'postCreated') {
    const { id, title } = data;
    posts[id] = { id, title, comments: [] };
    console.log(posts);
  } else if (type === 'commentCreated') {
    console.log(data);
    const { id, content, postId, status } = data;
    const post = posts[postId];
    post.comments.push({ id, content, status });
    console.log(posts);
  } else if (type === 'commentUpdated') {
    console.log(data);
    const { id, content, postId, status } = data;
    const post = posts[postId];
    const comment = post.comments.find((comment) => {
      return comment.id === id;
    });
    comment.status = status;
    comment.content = content;
  }
};

const posts = {};

app.post('/events', (req, res) => {
  console.log('called from query');
  const { type, data } = req.body;
  handleEvent(type, data);
  res.send({});
});

app.get('/posts', (req, res) => {
  console.log(posts);
  res.send(posts);
});

app.listen(4002, async () => {
  console.log('hello from posts. Listening on 4002');
  const res = await axios.get('http://event-bus-clusterip-srv:4005/events');
  for (let event of res.data) {
    console.log('Processing event:', event.type);
    handleEvent(event.type, event.data);
  }
});
